package Class;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Dolfi
 */
public interface Bill {
    public void itemsbill(JTable jtable1, JTextField cash, JLabel date, JLabel time);
}
